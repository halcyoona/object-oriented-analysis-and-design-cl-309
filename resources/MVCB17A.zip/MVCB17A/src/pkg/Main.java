package pkg;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student model = new Student();
		StudentView view = new StudentView();
		StudentController controller = new StudentController(model, view);
		controller.setStudentDetails();
		controller.updateView();
	}

}
