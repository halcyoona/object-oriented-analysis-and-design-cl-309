package pkg;

import javax.swing.JOptionPane;

public class StudentView {
	public String vSetRollNo(){
		String rno = JOptionPane.showInputDialog("Enter your RollNo");
		return rno;
	}
	public String vSetName(){
		String name = JOptionPane.showInputDialog("Enter your Name");
		return name;
	}
	public void printStudentDetails(String rollno, String name){
		System.out.println("Student's Detail");
		System.out.println("Roll No: "+rollno);
		System.out.println("Name: "+name);
	}

}
