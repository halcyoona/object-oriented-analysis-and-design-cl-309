package pkg;

/*
 * This the model
 */
public class Student {
	private String rollno;
	private String name;
	
	public void setRollNo(String rno){
		rollno = rno;
	}
	public void setName(String name){
		this.name = name;
	}
	public String getRollNo(){
		return rollno;
	}
	public String getName(){
		return name;
	}
}
