package pkg;

public class StudentController {
	private Student model;
	private StudentView view;
	
	public StudentController(Student model, StudentView view){
		this.model = model;
		this.view = view;
	}
	
	public void setStudentDetails(){
		model.setRollNo(view.vSetRollNo());
		model.setName(view.vSetName());
	}
	
	public void updateView(){
		view.printStudentDetails(model.getRollNo(), model.getName());
	}

}
